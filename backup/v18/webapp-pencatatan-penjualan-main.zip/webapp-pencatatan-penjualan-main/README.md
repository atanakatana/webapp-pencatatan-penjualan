# webapp-pencatatan-penjualan
Repo yang berisi project nekat yang diambil berdasarkan keberanian dan keyakinan. PS keberanian dan keyakinan yang dimaksud didasari oleh pengetahuan dan pengalaman yang seadanya.
